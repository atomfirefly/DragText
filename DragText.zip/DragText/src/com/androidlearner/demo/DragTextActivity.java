package com.androidlearner.demo;

import com.androidlearner.dragText.R;
import com.androidlearner.widget.DTextView;
import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

public class DragTextActivity extends Activity {
	DTextView mDragText ;
	int [] mParams ;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        Log.e("qt", " on create");
        
        mDragText = (DTextView) findViewById(R.id.dragText);
    }
    
    @Override
	protected void onPause() {
    	Log.e("qt", " on pause");
    	
		super.onPause();
		mParams = mDragText.getCurrentLayout();
	}
    
	@Override
	protected void onResume() {
		Log.e("qt", " on Resume");
		
		super.onResume();
		if(mParams != null){
			mDragText.layout(mParams[0] , mParams[1], mParams[2], mParams[3]);
		}
	}

}